import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.scss'],
})
export class SampleComponent implements OnInit {
  constructor(private fb: FormBuilder) {}
  checkedMsg: string = 'checkbox enable';
  uncheckedMsg: string = 'checkbox disable';
  displayMsg!: string;
  loginform!: FormGroup;
  showMe: boolean = false;
  ngOnInit() {}

  enableCheckbox(chk: any) {
    if (chk.checked === false) {
      chk.checked = true;
    } else {
      chk.checked = false;
    }
  }

  enablechk(chk1: any) {
    if (chk1.checked === false) {
      chk1.checked = true;
      this.displayMsg = this.checkedMsg;
    } else {
      chk1.checked = false;
      this.displayMsg = this.uncheckedMsg;
    }
  }
  submitForm(form: NgForm) {
    if (form.valid) {
      // Form is valid, perform submission or other actions here
    }
  }
}
